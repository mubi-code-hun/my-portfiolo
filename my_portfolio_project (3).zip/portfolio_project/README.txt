MY PORTFOLIO PROJECT

FILES
- index.html: the portfolio webpage
- styles.css: all the styling

HOW TO OPEN IN VISUAL STUDIO CODE
1. Extract the ZIP file.
2. Open Visual Studio Code.
3. Select File > Open Folder and choose the portfolio_project folder.
4. Open index.html.
5. If you have the Live Server extension, right-click index.html and choose "Open with Live Server".
   Otherwise, open index.html in your browser.

IMPORTANT
- Keep index.html and styles.css in the same folder.
- The HTML already links the CSS with:
  <link rel="stylesheet" href="styles.css">
- Replace "Your Name" and the sample biography, projects and email address with your own details.
- The Roboto font is loaded from Google Fonts, so an internet connection is needed for that font.
